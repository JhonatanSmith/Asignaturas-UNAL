library(gmodels)
library(multcomp)
library(daewr)
library(car)

#CREANDO FUNCI�N USUARIO mismediastratamientos()
mismediastratamientos=function(modeloanova,nivel=95){
MSE=anova(modeloanova)["Mean Sq"][2,]
df=anova(modeloanova)["Df"][2,]
ni=unlist(model.tables(modeloanova,type = "means")["n"])
alfa=1-nivel/100
alfa.med=(1-(nivel/100))/2
t=qt(alfa.med,df=df,lower.tail=F)
medias.tratam=unlist(model.tables(modeloanova,type = "means")["tables"])[-1]
interval=cbind(ni=ni,Medias=medias.tratam,LIC=medias.tratam-t*sqrt(MSE/ni),LSC=medias.tratam+t*sqrt(MSE/ni))
cat("Tabla de medias de tratamientos y sus I.C de",nivel,"%","\n")
cat("alfa","               ",alfa,"\n")
cat("grados de libertad    ",df,"\n")
cat("error cuadr�tico medio",MSE,"\n")
cat("valor cr�tico t       ",t,"\n","\n")
interval
}


#ENTRADA DE DATOS:
ni=c(6,9,12)
dise�o=data.frame(ID=factor(rep(c("alto","bajo","medio"),times=ni)),mprod=scan())
8.5 9.7 10.1 7.8 9.6 9.5
7.6 8.2 6.8 5.8 6.9 6.6 6.3 7.7 6.0 
6.7 8.1 9.4 8.6 7.8 7.7 8.9 7.9 8.3 8.7 7.1 8.4

dise�o

attach(dise�o)

#CALCULANDO MEDIAS DE TRATAMIENTO PARA LUEGO USAR EN GR�FICA DE BOXPLOTS
mediasy=sapply(split(mprod,ID),mean)
#BOXPLOTS COMPARATIVOS
boxplot(mprod~ID,boxwex = 0.5)
lines(1:3,mediasy,col=2,lty=2,type="b",pch=19)

#AJUSTE MODELO ANOVA UN FACTOR
modelo=aov(mprod~ID)

#OBTENIENDO TABLA ANOVA
anova(modelo) 
#o bien 
summary(modelo)

#OBTENIENDO MEDIAS ESTIMADAS POR NIVEL DEL FACTOR
model.tables(modelo,type = "means",se=TRUE)

#OBTENCI�N DE MEDIAS DE TRATAMIENTO CON SUS I.C DEL 95%
mismediastratamientos(modelo)
library(lsmeans)
lsmeans(modelo,~ID) #esta funci�n hace lo mismo que mismediastratamientos()
lsmeans(modelo,"ID")

#ESTIMACI�N DE LOS EFECTOS PRINCIPALES:
model.tables(modelo,type = "effects",se=TRUE)


#C�LCULO DE LOS EFECTOS DE TRATAMIENTOS IGNORANDO DESBALANCE, SUS TESTES T Y I.C DEL 95%:
#La funci�n fit.contrast requiere la librer�a gmodels
efect.alto=fit.contrast(modelo,"ID",rbind(":efecto alto"=c(2/3,-1/3,-1/3)),conf=0.95)
efect.bajo=fit.contrast(modelo,"ID",rbind(":efecto bajo"=c(-1/3,2/3,-1/3)),conf=0.95)
efect.medio=fit.contrast(modelo,"ID",rbind(":efecto medio"=c(-1/3,-1/3,2/3)),conf=0.95)
rbind(efect.alto,efect.bajo,efect.medio)

#OTRA FORMA PARA C�LCULO INDIVIDUAL DE EFECTOS CON SUS INTERVALOS DE CONFIANZA DEL 95%:
#LA FUNCI�N glht REQUIERE LA LIBRER�A multcomp
contr.alto= rbind("efecto id alto"= c(2/3,-1/3,-1/3))
contr.bajo= rbind("efecto id bajo"= c(-1/3,2/3,-1/3))
contr.medio= rbind("efecto id medio"= c(-1/3,-1/3,2/3))

rbind(confint(glht(modelo,linfct=mcp(ID=contr.alto)))$confint,
confint(glht(modelo,linfct=mcp(ID=contr.bajo)))$confint,
confint(glht(modelo,linfct=mcp(ID=contr.medio)))$confint) 

#CORRECCI�N POR DESBALANCE, DE LA ESTIMACI�N PUNTUAL Y POR I.C DEL 95% PARA EFECTOS DE TRATAMIENTOS
efect.alto=fit.contrast(modelo,"ID",rbind(":efecto alto"=c(21/27,-9/27,-12/27)),conf=0.95)
efect.bajo=fit.contrast(modelo,"ID",rbind(":efecto bajo"=c(-6/27,18/27,-12/27)),conf=0.95)
efect.medio=fit.contrast(modelo,"ID",rbind(":efecto medio"=c(-6/27,-9/27,15/27)),conf=0.95)
rbind(efect.alto,efect.bajo,efect.medio)

contr.alto= rbind("efecto id alto"= c(21/27,-9/27,-12/27))
contr.bajo= rbind("efecto id bajo"= c(-6/27,18/27,-12/27))
contr.medio= rbind("efecto id medio"= c(-6/27,-9/27,15/27))

rbind(confint(glht(modelo,linfct=mcp(ID=contr.alto)))$confint,
confint(glht(modelo,linfct=mcp(ID=contr.bajo)))$confint,
confint(glht(modelo,linfct=mcp(ID=contr.medio)))$confint) 

#GR�FICOS PARA AN�LISIS DE RESIDUOS INTERNAMENTE ESTUDENTIZADOS
layout(rbind(c(1,1,2,2),c(0,3,3,0)))
stripchart(rstandard(modelo)~ID,vertical=TRUE,ylim=c(-2.5,2.5),pch=1,cex=1)
abline(h=c(-2,0,2),lty=2)
plot(fitted(modelo),rstandard(modelo),ylim=c(-2.5,2.5))
abline(h=c(-2,0,2),lty=2)
qqnorm(rstandard(modelo))
qqline(rstandard(modelo),lty=2)

plot(modelo)

#TESTS DE HOMOGENEIDAD DE VARIANZAS
bartlett.test(mprod~ID,data=dise�o)

library(car)
leveneTest(mprod~ID,data=dise�o,center="median") #usando la mediana para centrar
leveneTest(mprod~ID,data=dise�o,center="mean") #usando la media para centrar
leveneTest(mprod~ID,data=dise�o,center="mean",trim=0.1) #usando media recortada al 10% para centrar

#O bien 
library(lawstat)
levene.test(dise�o$mprod,dise�o$ID,location="median") #usando la mediana para centrar
levene.test(dise�o$mprod,dise�o$ID,location="mean")#usando la media para centrar
levene.test(dise�o$mprod,dise�o$ID,location="trim.mean",trim.alpha=0.1) #usando media recortada al 10% para centrar

#INTERVALOS DE TUKEY
TukeyHSD(modelo, conf.level = 0.95) #Funci�n es cargada por defecto por librer�a stats 
plot(TukeyHSD(modelo, conf.level = 0.95),cex.lab=0.8,las=1)

library(agricolae)
HSD.test(modelo,"ID", group=TRUE,console=TRUE) #Comparaciones de Tukey
duncan.test(modelo,"ID",alpha=0.05,group=TRUE,console=TRUE) #Rango m�ltiple de Duncan
LSD.test(modelo,"ID",group=TRUE,console=TRUE) #M�todo LSD

#Uso librer�a multcomp para Dunnett. Como Dunnett asume que primer nivel es el control
#Para cambiar el nivel de control usamos relevel
ID2=relevel(ID,ref="bajo")
modelo2=aov(mprod~ID2)
summary(glht(modelo2, linfct=mcp(ID2="Dunnett"),alternative="two.sided")) 
confint(glht(modelo2, linfct=mcp(ID2="Dunnett"),alternative="two.sided"))

#CONTRASTE ID: ALTO VS. DEM�S, TEST T Y I.C DEL 95%:
fit.contrast(modelo,"ID",rbind(":ALTO VS. DEMAS"=c(1,-1/2,-1/2)),conf=0.95)

#OTRA FORMA PARA C�LCULO DEL CONTRASTE ID. ALTO VS. DEM�S, Y SU I.C DEL 95%
contrasteb=rbind("alto vs. dem�s "=c(1,-1/2,-1/2))
confint(glht(modelo,linfct=mcp(ID=contrasteb),alternative="two.sided"))
summary(glht(modelo,linfct=mcp(ID=contrasteb),alternative="two.sided"))

#TEST ID. ALTO MAYOR QUE DEM�S, 
summary(glht(modelo,linfct=mcp(ID=contrasteb),alternative="greater"))

detach(dise�o)




